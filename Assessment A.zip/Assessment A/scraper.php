<?php

require 'vendor/autoload.php';

use Sunra\PhpSimple\HtmlDom;

$date_threshold = '01/01/2022';
$url = 'https://www.theverge.com/';

$html = new HtmlDom;
$html->load_file($url);

$headlines_sorted = [];

foreach ($html->find('h3.c-entry-box-compact__title a.c-entry-box-compact__link') as $element) {
    $article_url = $element->href;
    $html->load_file($article_url);
    $article_date = $html->find('.c-meta-date time', 0)->datetime;

    if (strtotime($article_date) >= strtotime($date_threshold)) {
        array_unshift($headlines_sorted, [
            'title' => $element->plaintext,
            'url' => $article_url,
            'date' => $article_date
        ]);
    }
}

$json = json_encode(array_reverse($headlines_sorted));
echo $json;

?>