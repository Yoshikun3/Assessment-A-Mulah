const headlinesElement = document.getElementById('headlines');

fetch('scraper.php')
    .then(response => response.json())
    .then(data => {
        data.forEach(headline => {
            const li = document.createElement('li');
            li.innerHTML = `<a href="${headline.url}">${headline.title}</a>`;
            headlinesElement.appendChild(li);
        });
    });